load facesYale
[nr nc N] =size(X);
K=99; montage(reshape(X(:,:,1:K),[nr nc 1 K]))

 